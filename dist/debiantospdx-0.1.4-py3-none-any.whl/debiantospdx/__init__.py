# from や import でパッケージ名を指定するとこのファイルが呼ばれる
# 外部に公開する関数をimport

# pyproject.tomlと合わせる
__version__ = "0.1.4"
